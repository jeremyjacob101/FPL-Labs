module CodeGenerator

open System.IO
open Definitions
open SymbolTable

let mutable writer: StreamWriter option = None

let mutable labelCounter = 0
let mutable currentFunctionName = "" // fully resolved function name eg Main.main
let mutable currentClassName = ""

let nextLabel prefix =
    labelCounter <- labelCounter + 1
    currentFunctionName + "$" + prefix + string labelCounter

let writeData (text: string) =
    // indent all lines except for comments and function declarations for better readability of the generated VM code
    let formattedText =
        if text.StartsWith("//") || text.StartsWith("function") then
            text + "\n"
        else
            "\t" + text + "\n"

    Option.get(writer).Write formattedText

//#region VM command abstractions

let segmentToString segment =
    match segment with
    | CONST -> "constant"
    | ARG -> "argument"
    | LOCAL -> "local"
    | STATIC -> "static"
    | THIS -> "this"
    | THAT -> "that"
    | POINTER -> "pointer"
    | TEMP -> "temp"

let writePush (segment: Segment) (index: int) =
    writeData ([ "push"; segmentToString segment; index.ToString() ] |> String.concat " ")

let writePop (segment: Segment) (index: int) =
    writeData ([ "pop"; segmentToString segment; index.ToString() ] |> String.concat " ")

let writeArithmetic (command: ArithmeticCommand) =
    writeData (command.ToString().ToLower())

let writeLabel (label) = writeData ("label " + label)
let writeGoTo label = writeData ("goto " + label)
let writeIf label = writeData ("if-goto " + label)

let writeCall (functionName: string) (numArgs: int) =
    writeData ([ "call"; functionName; numArgs.ToString() ] |> String.concat " ")

let writeFunction (functionName: string) (numLocals: int) =
    writeData ([ "function"; functionName; numLocals.ToString() ] |> String.concat " ")

let writeReturn () = writeData "return"

//#endregion

let segmentOfSymbolKind kind =
    match kind with
    | Static -> STATIC
    | Field -> THIS
    | Argument -> ARG
    | Var -> LOCAL

let matchNode (expectedKind: string) (node: Node) =
    match node with
    | Node(kind, _) when kind = expectedKind -> true
    | _ -> false

let getChildren (expectedKind: string) (node: Node) =
    match node with
    | Node(kind, children) when kind = expectedKind -> children
    | _ -> failwithf "Expected node of kind %A, received %A" expectedKind node

let getTokenValue (expectedKind: TokenType) (node: Node) =
    match node with
    | Token(kind, value) when kind = expectedKind -> value
    | _ -> failwithf "Expected token of kind %A, received %A" expectedKind node

let getTypeName node =
    match node with
    | Token(Identifier, value) -> value
    | Token(Keyword, value) ->
        if List.contains value [ "void"; "int"; "char"; "boolean" ] then
            value
        else
            ""
    | _ -> ""

let writePushVariable name =
    writePush (kindOf name |> segmentOfSymbolKind) (indexOf name)

let writePopVariable name =
    writePop (kindOf name |> segmentOfSymbolKind) (indexOf name)

//#region recursively travserse the parse tree and generate code



let rec writeExpression (node: Node) =
    let children = getChildren "expression" node
    writeTerm children[0]

    // handle a list of operator-term pairs, e.g. `term op term op term ...`, skipping the first term since it has already been written
    let opTermPairs = List.chunkBySize 2 (List.tail children)

    for pair in opTermPairs do
        writeTerm pair[1]
        writeOp pair[0]

and writeSubroutineCall (nodes: Node list) =
    let subroutineCallPrefix = getChildren "subroutineCallPrefix" nodes[0]

    let prefixParts = subroutineCallPrefix |> List.map (getTokenValue Identifier)

    let functionName, thisParam =
        match prefixParts with
        // if method on current object
        | [ subroutineName ] -> currentClassName + "." + subroutineName, Some(POINTER, 0)
        // if method on diff object or class function
        | [ prefixName; subroutineName ] ->
            // find prefixName entry in symbol table
            match lookup prefixName with
            | Some(prefixName, typeName, kind, index) ->
                typeName + "." + subroutineName, Some(segmentOfSymbolKind kind, index)
            | None -> prefixName + "." + subroutineName, None
        | _ -> failwithf "Unexpected subroutine call prefix %A" prefixParts

    if thisParam.IsSome then
        let segment, index = Option.get thisParam
        writePush segment index

    let expressions = getChildren "expressionList" nodes[1]
    expressions |> List.iter writeExpression
    writeCall functionName (expressions.Length + Option.count thisParam)

and writeArrayAddress arrayName indexExpression =
    writePushVariable arrayName
    writeExpression indexExpression
    writeArithmetic ADD

and writeTerm (node: Node) =
    match node with
    | Token(IntConst, value) -> writePush CONST (int value)
    | Token(Identifier, id) -> writePushVariable id
    | Token(Keyword, "true") ->
        writePush CONST 1
        writeArithmetic NEG // true is represented as -1 in Hack
    | Token(Keyword, "false") -> writePush CONST 0
    | Token(Keyword, "null") -> writePush CONST 0
    | Token(Keyword, "this") -> writePush POINTER 0
    | Token(StringConst, value) ->
        writePush CONST value.Length
        writeCall "String.new" 1

        value
        |> Seq.iter (fun character ->
            writePush CONST (int character)
            writeCall "String.appendChar" 2)
    | Node("unaryOpTerm", children) ->
        writeTerm children[1]

        match children[0] with
        | Token(Symbol, "-") -> writeArithmetic NEG
        | Token(Symbol, "~") -> writeArithmetic NOT
        | _ -> failwithf "Unknown unary operator %A" children[0]
    | Node("subroutineCall", children) -> writeSubroutineCall children
    | Node("expression", _) -> writeExpression node
    | Node("arrayAccess", children) ->
        let arrayName = getTokenValue Identifier children[0]
        writeArrayAddress arrayName children[1]
        writePop POINTER 1
        writePush THAT 0
    | _ -> writeData (sprintf "// unhandled node %A" node)

and writeOp (node: Node) =
    match node with
    | Token(Symbol, "+") -> writeArithmetic ADD
    | Token(Symbol, "-") -> writeArithmetic SUB
    | Token(Symbol, "*") -> writeCall "Math.multiply" 2
    | Token(Symbol, "/") -> writeCall "Math.divide" 2
    | Token(Symbol, "=") -> writeArithmetic EQ
    | Token(Symbol, ">") -> writeArithmetic GT
    | Token(Symbol, "<") -> writeArithmetic LT
    | Token(Symbol, "&") -> writeArithmetic AND
    | Token(Symbol, "|") -> writeArithmetic OR
    | _ -> failwithf "Unknown operator %A" node


let rec writeStatement node =

    let writeLetStatement (nodes: Node list) =
        match nodes with
        | [ Token(Identifier, name); valueExpression ] ->
            writeExpression valueExpression
            writePopVariable name
        | [ Token(Identifier, arrayName); indexExpression; valueExpression ] ->
            writeArrayAddress arrayName indexExpression
            writeExpression valueExpression
            writePop TEMP 0
            writePop POINTER 1
            writePush TEMP 0
            writePop THAT 0
        | _ -> failwithf "Unexpected let statement %A" nodes

    let writeIfStatement (nodes: Node list) =
        let afterLabel = nextLabel "IF_AFTER_"
        let elseLabel = if nodes.Length = 3 then nextLabel "ELSE_" else ""
        let falseLabel = if elseLabel = "" then afterLabel else elseLabel

        writeExpression nodes[0] // condition
        writeArithmetic NOT // invert the condition - no short circuiting and true/false values to track
        writeIf falseLabel // if false, jump to else/after
        getChildren "statements" nodes[1] |> List.iter writeStatement // true statements

        if elseLabel <> "" then // if there is an else
            writeGoTo afterLabel // jump to `next` after finishing the if
            writeLabel elseLabel
            getChildren "statements" nodes[2] |> List.iter writeStatement // else statements

        writeLabel afterLabel

    let writeWhileStatement (nodes: Node list) =
        let loopLabel = nextLabel "LOOP_"
        let condLabel = nextLabel "DO_COND_"

        // write the `while` more like a `do-while` to avoid inverting the condition
        writeGoTo condLabel // test condition first
        writeLabel loopLabel
        getChildren "statements" nodes[1] |> List.iter writeStatement // loop statements
        writeLabel condLabel
        writeExpression nodes[0]
        writeIf loopLabel // jump back to top if true, fall if false

    let writeDoStatement (node: Node) =
        writeTerm node // subroutine call is also a term of an expression
        // do statements discard the return value, so we pop it off the stack
        writePop TEMP 0

    let writeReturnStatement (nodes: Node list) =
        if nodes.Length = 0 then
            writePush CONST 0 // return void
        else
            writeExpression nodes[0] // return expression

        writeReturn ()

    // write statement
    match node with
    | Node("letStatement", children) -> writeLetStatement children
    | Node("ifStatement", children) -> writeIfStatement children
    | Node("whileStatement", children) -> writeWhileStatement children
    | Node("doStatement", children) -> writeDoStatement children[0]
    | Node("returnStatement", children) -> writeReturnStatement children
    | x -> failwithf "Unknown statement %A" x

let writeSubroutine className node =
    resetSubScope ()
    currentClassName <- className

    let children = getChildren "subroutineDec" node
    let subroutineType = getTokenValue Keyword children[0]

    if subroutineType = "method" then
        addToSymbolTable "this" className Argument

    let returnType = getTypeName children[1]
    let subroutineName = className + "." + getTokenValue Identifier children[2]
    currentFunctionName <- subroutineName

    let parameterList = children[3]

    // write parameters to subroutine symbol table
    getChildren "parameterList" parameterList
    |> List.iter (fun parameter ->
        let parameterChildren = getChildren "parameter" parameter
        addToSymbolTable (getTokenValue Identifier parameterChildren[1]) (getTypeName parameterChildren[0]) Argument)

    let userParamLength = getChildren "parameterList" parameterList |> List.length
    // methods also take a `this` param
    let paramLength = userParamLength + (if subroutineType = "method" then 1 else 0)

    writeData (
        [ "//"
          subroutineType
          subroutineName
          paramLength.ToString()
          "->"
          returnType ]
        |> String.concat " "
    )

    let subroutineBodyChildren = getChildren "subroutineBody" children[4]

    let varDecNodes = List.filter (matchNode "varDec") subroutineBodyChildren

    // write local vars to subroutine symbol table
    varDecNodes
    |> List.iter (fun varDec ->
        let varDecChildren = getChildren "varDec" varDec

        varDecChildren
        |> List.skip 1 // skip only type (`var` kind is thrown away because subroutine varDec only way to get here: no new info)
        |> List.iter (fun node -> addToSymbolTable (getTokenValue Identifier node) (getTypeName varDecChildren[0]) Var))

    writeFunction subroutineName (numVarsOfKind Var)

    // do setup according to the type of function
    match subroutineType with
    | "method" -> // set up "this"
        writePush ARG 0
        writePop POINTER 0
    | "constructor" -> // allocate memory and set up "this"
        let fieldCount = numVarsOfKind Field
        writePush CONST fieldCount
        writeCall "Memory.alloc" 1
        writePop POINTER 0
    | "function" -> () // no special setup required
    | _ -> failwithf "Unknown subroutine type %A" subroutineType

    let statementsNode =
        List.tryFind (matchNode "statements") subroutineBodyChildren
        |> Option.defaultValue (Node("statements", []))

    let statements = getChildren "statements" statementsNode

    statements |> List.iter writeStatement

    writeData "\n"


let writeClass node =
    resetScopes ()

    let children = getChildren "class" node

    let className = getTokenValue Identifier (children[0])

    writeData ("// class " + className + "\n")

    // write classVarDecs to class symbol table
    children
    |> List.filter (matchNode "classVarDec")
    |> List.iter (fun classVarDec ->
        let classVarDecChildren = getChildren "classVarDec" classVarDec

        let kind =
            match getTokenValue Keyword classVarDecChildren[0] with
            | "static" -> Static
            | "field" -> Field
            | x -> failwithf "Unknown class variable kind %s" x

        classVarDecChildren
        |> List.skip 2 // skip kind and type
        |> List.iter (fun node ->
            addToSymbolTable (getTokenValue Identifier node) (getTypeName classVarDecChildren[1]) kind))

    // handle subroutines
    children
    |> List.filter (matchNode "subroutineDec")
    |> List.iter (writeSubroutine className)

//#endregion

let writeProgram (f: FileStream) (rootNode: Node) =
    use _writer = new StreamWriter(f)
    writer <- Some(_writer)
    writeClass rootNode
